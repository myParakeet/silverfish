using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_FP1_010 : SimTemplate //maexxna
	{

//    vernichtet jeden diener, der von diesem diener verletzt wurde.


	}
}