using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_116 : SimTemplate //Mekgineer Thermaplugg
    {

        //   Whenever an enemy minion dies, summon a Leper Gnome.
        //done in trigger a minion died


    }

}