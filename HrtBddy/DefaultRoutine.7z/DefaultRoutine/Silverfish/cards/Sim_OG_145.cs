using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_OG_145 : SimTemplate //* Psych-o-Tron
	{
		//Taunt. Divine Shield
	}
}