using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_080t : SimTemplate //Druid of the Fang better form :D
    {

       // 7/7 minion

    }

}