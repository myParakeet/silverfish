using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_045t : SimTemplate //Imp
    {

        //   just an imp

       


    }

}