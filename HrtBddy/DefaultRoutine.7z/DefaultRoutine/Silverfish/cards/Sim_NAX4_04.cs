using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NAX4_04 : SimTemplate //* Raise Dead
	{
		//Passive Hero Power: Whenever an enemy dies, raise a 1/1 Skeleton.
		//Handled in triggerAMinionDied()
	}
}