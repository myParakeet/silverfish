﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_BRM_031 : SimTemplate //Chromaggus
    {

        //   Whenever you draw a card, put another copy into your hand.

    }
}