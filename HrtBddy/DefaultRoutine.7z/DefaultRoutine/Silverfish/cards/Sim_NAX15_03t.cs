using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NAX15_03t : SimTemplate //* Guardian of Icecrown
	{
		//Taunt
	}
}