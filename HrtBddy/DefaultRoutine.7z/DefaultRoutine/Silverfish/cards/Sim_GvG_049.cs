using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_049 : SimTemplate //Gahz'rilla
    {

        //   Whenever this minion takes damage, double its Attack.

        


    }

}