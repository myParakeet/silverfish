using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_098 : SimTemplate //Gnomeregan Infantry
    {

        //   Charge Taunt

        


    }

}