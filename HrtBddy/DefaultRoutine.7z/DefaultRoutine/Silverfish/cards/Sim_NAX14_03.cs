using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NAX14_03 : SimTemplate //* Frozen Champion
	{
		//Permanently Frozen.  Adjacent minions are Immune to Frost Breath.
		// Handled in Frost Breath
	}
}