using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_007 : SimTemplate //Flame Leviathan
    {

        //    When you draw this, deal 2 damage to all characters.
        // todo simulate this (but not if we dont know our deck :D)

    }

}