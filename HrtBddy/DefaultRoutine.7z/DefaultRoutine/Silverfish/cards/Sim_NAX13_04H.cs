using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NAX13_04H : SimTemplate //* Feugen
	{
		//-
	}
}