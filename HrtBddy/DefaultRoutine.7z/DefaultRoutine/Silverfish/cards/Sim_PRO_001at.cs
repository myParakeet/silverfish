using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_PRO_001at : SimTemplate //murloc
	{

//
		

	}
}