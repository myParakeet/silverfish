using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_065 : SimTemplate //Ogre Brute
    {

        //   50% chance to attack the wrong enemy.

    }

}