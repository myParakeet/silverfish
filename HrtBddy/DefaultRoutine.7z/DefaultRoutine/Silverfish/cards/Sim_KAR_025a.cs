using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_KAR_025a : SimTemplate //1/1 Candle
    {

    }
}