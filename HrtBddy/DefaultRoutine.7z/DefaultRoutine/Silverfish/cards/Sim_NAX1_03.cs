using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NAX1_03 : SimTemplate //* Nerubian
	{
		//-
	}
}