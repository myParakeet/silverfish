using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_OG_031a : SimTemplate //* Twilight Elemental
	{
		
	}
}