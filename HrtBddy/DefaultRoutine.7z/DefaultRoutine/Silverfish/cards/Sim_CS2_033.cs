using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_CS2_033 : SimTemplate //waterelemental
	{

//    friert/ jeden charakter ein, der von diesem diener verletzt wurde.

	}
}