using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_067 : SimTemplate //Magnataur Alpha
    {

        //  Also damages the minions next to whomever he attacks. 
        //done in minionAttacksMinion

    }

}