using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_OG_308 : SimTemplate //* Giant Sand Worm
	{
        //Whenever this minion kills another minion, it may attack again.
        
	}
}