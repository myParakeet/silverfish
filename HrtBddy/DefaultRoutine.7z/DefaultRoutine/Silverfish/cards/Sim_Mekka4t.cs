using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_Mekka4t : SimTemplate //chicken
	{

//    i&gt;put, put, put!/i&gt;
		

	}
}