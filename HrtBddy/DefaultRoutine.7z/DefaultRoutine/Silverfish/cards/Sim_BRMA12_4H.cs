using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BRMA12_4H : SimTemplate //* Brood Affliction: Green
	{
		//While this is in your hand, restore 6 health to your opponent at the start of your turn.
	}
}