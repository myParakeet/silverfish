﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_LOEA10_3 : SimTemplate //murloc tinyfin (0/1/1 minion)
    {


    }
}