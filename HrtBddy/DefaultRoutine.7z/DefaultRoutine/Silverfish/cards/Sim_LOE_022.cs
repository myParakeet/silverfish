using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_LOE_022 : SimTemplate //reliquary seeker
	{
        //taunt

        

	}

}
