using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_LOE_107 : SimTemplate //Eerie Statue
	{
        //Cant attack unless its the only minion in the battlefield.

        //updates his readyness if minion dies or is summoned

        public override void getBattlecryEffect(Playfield p, Minion own, Minion target, int choice)
        {
           
        }

	}

}
