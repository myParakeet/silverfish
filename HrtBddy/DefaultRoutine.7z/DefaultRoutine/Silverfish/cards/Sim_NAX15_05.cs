using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NAX15_05 : SimTemplate //* Mr. Bigglesworth
	{
		//This is Kel'Thuzad's kitty.
	}
}