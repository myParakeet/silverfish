using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_118 : SimTemplate //Troggzor the Earthinator
    {

        // Whenever your opponent casts a spell, summon a Burly Rockjaw Trogg.
  
        //done in triggerACardWillBePlayed


        


    }

}