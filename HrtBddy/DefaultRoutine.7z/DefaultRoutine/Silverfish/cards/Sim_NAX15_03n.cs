using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NAX15_03n : SimTemplate //* Guardian of Icecrown
	{
		//Taunt
	}
}