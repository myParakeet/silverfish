using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_FP1_002t : SimTemplate //spectralspider
	{

//
		

	}
}