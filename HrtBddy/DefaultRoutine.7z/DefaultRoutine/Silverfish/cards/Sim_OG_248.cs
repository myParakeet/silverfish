using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_OG_248 : SimTemplate //* Am'gam Rager
	{
		
	}
}