﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BRM_006t : SimTemplate //* Imp
	{

	}
}