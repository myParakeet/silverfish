using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_111t : SimTemplate //V-07-TR-0N
    {

        //   Charge Mega-Windfury(Can attack four times a turn.)
       

    }

}