using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_018 : SimTemplate //Mistress of Pain
    {

        //    Whenever this minion deals damage, restore that much Health to your hero.

        //done in triggerAMinionDealedDmg (Playfield) (cause its the only minion with such an trigger)


    }

}