using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BRMA09_2t : SimTemplate //* 1/1 whelp
	{
		//-
	}
}