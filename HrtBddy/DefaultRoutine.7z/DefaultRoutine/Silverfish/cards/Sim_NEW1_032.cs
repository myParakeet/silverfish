using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NEW1_032 : SimTemplate //misha
	{

//    spott/
		

	}
}