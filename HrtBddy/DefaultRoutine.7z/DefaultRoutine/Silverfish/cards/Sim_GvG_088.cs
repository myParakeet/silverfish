using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_088 : SimTemplate //Ogre Ninja
    {

        //  Stealth 

        

    }

}