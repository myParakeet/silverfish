﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_BRM_020 : SimTemplate //Dragonkin Sorcerer
    {

        //    Whenever you target this minion with a spell, gain +1/+1.


    }
}