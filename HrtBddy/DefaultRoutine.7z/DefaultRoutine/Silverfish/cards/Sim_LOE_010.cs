using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_LOE_010 : SimTemplate //pitsnake
	{

        //    Destroy any minion damaged by this minion.

	}
}