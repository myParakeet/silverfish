using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BRMA17_6 : SimTemplate //* 2/1 Bone Construct
	{
		//-
	}
}