using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_KAR_711 : SimTemplate //Arcane Giant
    {
        // Costs (1) less for each spell you've cast this game.

    }
}