using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_113 : SimTemplate //Foe Reaper 4000
    {

        //  Also damages the minions next to whomever he attacks. 
        //done in minionAttacksMinion

    }

}