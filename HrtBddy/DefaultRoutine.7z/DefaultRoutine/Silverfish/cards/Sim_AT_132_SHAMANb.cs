using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_AT_132_SHAMANb : SimTemplate //searingtotem
	{

// fire totem of shaman ability
		

	}
}