using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NAX7_02 : SimTemplate //* Understudy
	{
		//Taunt
	}
}