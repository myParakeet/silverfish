using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NAX4_04H : SimTemplate //* Raise Dead
	{
		//Passive Hero Power: Whenever an enemy dies, raise a 5/5 Skeleton.
		//Handled in triggerAMinionDied()
	}
}