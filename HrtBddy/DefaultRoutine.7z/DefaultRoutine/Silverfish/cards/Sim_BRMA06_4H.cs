using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BRMA06_4H : SimTemplate //* Flamewaker Acolyte
	{
		//-
	}
}