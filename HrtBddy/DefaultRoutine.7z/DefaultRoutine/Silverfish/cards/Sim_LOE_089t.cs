using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_LOE_089t : SimTemplate //runt
	{

        //simple 2/2

	}
}