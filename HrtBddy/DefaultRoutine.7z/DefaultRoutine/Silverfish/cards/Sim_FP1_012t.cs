using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_FP1_012t : SimTemplate //slime
	{

//    spott/
		

	}
}