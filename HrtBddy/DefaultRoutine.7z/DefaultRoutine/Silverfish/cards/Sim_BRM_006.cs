﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_BRM_006 : SimTemplate //Imp Gang Boss
    {

        //    Whenever this minion takes damage, summon a 1/1 Imp.

        //done in playfield triggerAMinionGotDmg()

    }
}