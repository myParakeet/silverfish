using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_skele21 : SimTemplate //damagedgolem
	{

//
		

	}
}