using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NEW1_010 : SimTemplate //alakirthewindlord
	{

//    windzorn/, ansturm/, gottesschild/, spott/
		

	}
}