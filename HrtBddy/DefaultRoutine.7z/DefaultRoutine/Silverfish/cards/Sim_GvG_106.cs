using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_GVG_106 : SimTemplate //Junkbot
    {

        //   Whenever a friendly Mech dies, gain +2/+2.

        // done in triggerAMinionDied


    }

}