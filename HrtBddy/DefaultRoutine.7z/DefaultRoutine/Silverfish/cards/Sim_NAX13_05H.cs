using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_NAX13_05H : SimTemplate //* Stalagg
	{
		//-
	}
}