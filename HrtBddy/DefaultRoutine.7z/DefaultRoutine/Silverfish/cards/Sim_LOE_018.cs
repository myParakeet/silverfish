using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
    class Sim_LOE_018 : SimTemplate //tunnel trogg
	{

        //    Whenever you Overload, gain +1 Attack per locked Mana Crystal.

        //done in playfield -> changeRecall


	}
}