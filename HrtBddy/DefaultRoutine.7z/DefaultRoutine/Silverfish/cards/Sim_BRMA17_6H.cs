using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_BRMA17_6H : SimTemplate //* 4/2 Bone Construct
	{
		//-
	}
}