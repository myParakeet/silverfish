using System;
using System.Collections.Generic;
using System.Text;

namespace HREngine.Bots
{
	class Sim_EX1_287 : SimTemplate //counterspell
	{
        //todo secret
//    geheimnis:/ wenn euer gegner einen zauber wirkt, kontert/ ihr ihn.

	}
}